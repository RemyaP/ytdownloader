SimpleInfiniteCarousel
======================

A sample to show how to make a simple infinite carousel with ViewPager on Android