/** Automatically generated file. DO NOT MODIFY */
package com.manishkpr.viewpagerimagegallery;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}