package com.bydavy.android;

//~--- non-JDK imports --------------------------------------------------------

import android.app.Activity;

import android.os.Bundle;

import android.util.Log;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;

import android.widget.BaseAdapter;
import android.widget.ImageView;

//~--- classes ----------------------------------------------------------------

public class UITest extends Activity {
    //~--- methods ------------------------------------------------------------

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        final CarouselLayout layout = (CarouselLayout) findViewById(R.id.carouselLayout);
        final CarouselAdapter adapter = new CarouselAdapter();

        layout.setAdapter(adapter);
        
        //Variant 2
        /*layout.setTranslate(50);
        layout.setSpaceBetweenViews(100);*/
        
        //Variant 3
        /*layout.setTranslate(50);
        layout.setSpaceBetweenViews(100);
        layout.setRotation(-10);*/
        
        //Variant 4
        layout.setTranslate(-50);
        //layout.setSpaceBetweenViews(100);
        layout.setSpaceBetweenViews(125);
        layout.setRotation(-10);
    }

    //~--- inner classes ------------------------------------------------------

    private class CarouselAdapter extends BaseAdapter {
        private int[] mImagesID = {
            //R.drawable.android1, 
            //R.drawable.android2, 
            //R.drawable.android3, 
            //R.drawable.android4, 
            //R.drawable.android5,
            //R.drawable.android6, 
            //R.drawable.android7, 
            R.drawable.android8, 
            R.drawable.android9
        };

        @Override
        public int getCount() {
            return mImagesID.length;
        }

        @Override
        public Object getItem(int position) {
            return mImagesID[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if ((position < 0) && (position > (getCount() - 1))) {
                Log.e("UITEST", "Unexistent position requested");

                return null;
            }

            ImageView imageView;
            if (convertView != null) {
                imageView = (ImageView) convertView;

            } else {            	
                imageView = new ImageView(getApplicationContext());
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
              //Layout params must be FILL_PARENT
                imageView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            }
            imageView.setImageResource(mImagesID[position]);

            return imageView;
        }
    }
}
